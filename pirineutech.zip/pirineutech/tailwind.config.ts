import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        accent: '#2D6A4F',
      },
      fontFamily: {
        geist: ['var(--font-geist)', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

export default config
